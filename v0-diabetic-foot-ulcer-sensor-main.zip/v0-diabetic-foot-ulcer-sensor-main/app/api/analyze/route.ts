import { type NextRequest, NextResponse } from "next/server"

const CLINICAL_THRESHOLDS = {
  PRESSURE_THRESHOLD_KPA: 200, // Peak pressure alert threshold
  SUSTAINED_PRESSURE_KPA: 4.7, // 35 mmHg sustained pressure
  TEMP_ASYMMETRY_THRESHOLD: 2.2, // High risk temperature difference (°C)
  TEMP_MODERATE_THRESHOLD: 1.5, // Moderate risk temperature difference (°C)
  FORCE_TO_KPA_FACTOR: 400.0 / 999.0, // Convert force sensor (0-999) to kPa
  HUMIDITY_LOW_THRESHOLD: 20,
  HUMIDITY_HIGH_THRESHOLD: 80,
}

interface SensorData {
  timestamp: string
  force_sensor_1_left?: number
  force_sensor_2_left?: number
  temperature_left?: number
  humidity_left?: number
  force_sensor_1_right?: number
  force_sensor_2_right?: number
  temperature_right?: number
  humidity_right?: number
  force_sensor_1?: number
  force_sensor_2?: number
  temperature?: number
  humidity?: number
}

interface AnalysisMetrics {
  [key: string]: number | string
}

interface Alert {
  title: string
  description: string
  severity: "low" | "moderate" | "high" | "critical"
}

interface ChartData {
  timestamp: string
  [key: string]: string | number
}

interface ClinicalInsight {
  category: string
  finding: string
  clinical_significance: string
  recommendation: string
}

interface AnalysisResult {
  overall_risk: {
    level: "low" | "moderate" | "high" | "critical"
    message: string
    recommendation: string
  }
  metrics: AnalysisMetrics
  alerts: Alert[]
  analysis: {
    [key: string]: number | string
  }
  chart_data: ChartData[]
  data_type: "bilateral" | "single"
  clinical_insights: ClinicalInsight[]
}

function parseCSV(content: string): SensorData[] {
  const lines = content.trim().split("\n")
  if (lines.length < 2) throw new Error("CSV file is empty")

  const headers = lines[0].split(",").map((h) => h.trim())
  const data: SensorData[] = []

  for (let i = 1; i < lines.length; i++) {
    const values = lines[i].split(",").map((v) => v.trim())
    const row: SensorData = { timestamp: values[0] }

    headers.forEach((header, idx) => {
      if (header !== "timestamp") {
        const value = Number.parseFloat(values[idx])
        if (!isNaN(value)) {
          row[header as keyof SensorData] = value
        }
      }
    })

    data.push(row)
  }

  return data
}

function calculateStats(values: number[]): { mean: number; std: number; min: number; max: number } {
  if (values.length === 0) return { mean: 0, std: 0, min: 0, max: 0 }

  const mean = values.reduce((a, b) => a + b, 0) / values.length
  const variance = values.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / values.length
  const std = Math.sqrt(variance)
  const min = Math.min(...values)
  const max = Math.max(...values)

  return { mean, std, min, max }
}

function detectAnomalies(values: number[], threshold = 2.5): number[] {
  const stats = calculateStats(values)
  const anomalies: number[] = []

  values.forEach((val, idx) => {
    const zScore = Math.abs((val - stats.mean) / (stats.std || 1))
    if (zScore > threshold) {
      anomalies.push(idx)
    }
  })

  return anomalies
}

function prepareChartData(data: SensorData[], isBilateral: boolean): ChartData[] {
  return data.map((row, idx) => {
    const chartRow: ChartData = {
      timestamp: `${idx}`,
    }

    if (isBilateral) {
      if (row.force_sensor_1_left !== undefined)
        chartRow["Pressure L1 (kPa)"] = Number(
          (row.force_sensor_1_left * CLINICAL_THRESHOLDS.FORCE_TO_KPA_FACTOR).toFixed(1),
        )
      if (row.force_sensor_2_left !== undefined)
        chartRow["Pressure L2 (kPa)"] = Number(
          (row.force_sensor_2_left * CLINICAL_THRESHOLDS.FORCE_TO_KPA_FACTOR).toFixed(1),
        )
      if (row.force_sensor_1_right !== undefined)
        chartRow["Pressure R1 (kPa)"] = Number(
          (row.force_sensor_1_right * CLINICAL_THRESHOLDS.FORCE_TO_KPA_FACTOR).toFixed(1),
        )
      if (row.force_sensor_2_right !== undefined)
        chartRow["Pressure R2 (kPa)"] = Number(
          (row.force_sensor_2_right * CLINICAL_THRESHOLDS.FORCE_TO_KPA_FACTOR).toFixed(1),
        )
      if (row.temperature_left !== undefined) chartRow["Temp Left (°C)"] = row.temperature_left
      if (row.temperature_right !== undefined) chartRow["Temp Right (°C)"] = row.temperature_right
    } else {
      if (row.force_sensor_1 !== undefined)
        chartRow["Pressure 1 (kPa)"] = Number((row.force_sensor_1 * CLINICAL_THRESHOLDS.FORCE_TO_KPA_FACTOR).toFixed(1))
      if (row.force_sensor_2 !== undefined)
        chartRow["Pressure 2 (kPa)"] = Number((row.force_sensor_2 * CLINICAL_THRESHOLDS.FORCE_TO_KPA_FACTOR).toFixed(1))
      if (row.temperature !== undefined) chartRow["Temperature (°C)"] = row.temperature
    }

    return chartRow
  })
}

function generateClinicalInsights(
  data: SensorData[],
  isBilateral: boolean,
  alerts: Alert[],
  metrics: AnalysisMetrics,
): ClinicalInsight[] {
  const insights: ClinicalInsight[] = []

  // Extract all pressure values and convert to kPa
  const allPressures: number[] = []
  const allTemperatures: number[] = []

  data.forEach((row) => {
    if (isBilateral) {
      if (row.force_sensor_1_left !== undefined)
        allPressures.push(row.force_sensor_1_left * CLINICAL_THRESHOLDS.FORCE_TO_KPA_FACTOR)
      if (row.force_sensor_2_left !== undefined)
        allPressures.push(row.force_sensor_2_left * CLINICAL_THRESHOLDS.FORCE_TO_KPA_FACTOR)
      if (row.force_sensor_1_right !== undefined)
        allPressures.push(row.force_sensor_1_right * CLINICAL_THRESHOLDS.FORCE_TO_KPA_FACTOR)
      if (row.force_sensor_2_right !== undefined)
        allPressures.push(row.force_sensor_2_right * CLINICAL_THRESHOLDS.FORCE_TO_KPA_FACTOR)
      if (row.temperature_left !== undefined) allTemperatures.push(row.temperature_left)
      if (row.temperature_right !== undefined) allTemperatures.push(row.temperature_right)
    } else {
      if (row.force_sensor_1 !== undefined)
        allPressures.push(row.force_sensor_1 * CLINICAL_THRESHOLDS.FORCE_TO_KPA_FACTOR)
      if (row.force_sensor_2 !== undefined)
        allPressures.push(row.force_sensor_2 * CLINICAL_THRESHOLDS.FORCE_TO_KPA_FACTOR)
      if (row.temperature !== undefined) allTemperatures.push(row.temperature)
    }
  })

  const pressureStats = calculateStats(allPressures)
  const tempStats = calculateStats(allTemperatures)

  // Pressure Analysis
  if (pressureStats.max > CLINICAL_THRESHOLDS.PRESSURE_THRESHOLD_KPA) {
    insights.push({
      category: "Pressure Distribution",
      finding: "Critical Peak Pressure",
      clinical_significance:
        "Peak pressure exceeding 200 kPa indicates severe localized stress. This is a critical risk factor for plantar ulcer formation in diabetic patients.",
      recommendation:
        "Immediate offloading intervention required. Consider specialized footwear, orthotics, or activity modification. Urgent podiatry consultation recommended.",
    })
  } else if (pressureStats.max > 150) {
    insights.push({
      category: "Pressure Distribution",
      finding: "Very High Peak Pressure",
      clinical_significance:
        "Peak pressure in the 150-200 kPa range indicates high risk for ulcer development. This exceeds safe thresholds for diabetic feet.",
      recommendation:
        "Implement pressure-relieving interventions. Schedule podiatry evaluation within 1-2 weeks. Monitor for skin changes.",
    })
  } else if (pressureStats.max > 100) {
    insights.push({
      category: "Pressure Distribution",
      finding: "Elevated Peak Pressure",
      clinical_significance:
        "Peak pressure in the 100-150 kPa range indicates moderate-to-high risk for ulcer development.",
      recommendation: "Consider gait analysis and physical therapy evaluation. Review footwear appropriateness.",
    })
  } else {
    insights.push({
      category: "Pressure Distribution",
      finding: "Normal Pressure Profile",
      clinical_significance: "Pressure readings are within acceptable ranges for diabetic foot monitoring.",
      recommendation: "Continue regular monitoring. Maintain current activity and footwear practices.",
    })
  }

  // Temperature Analysis
  if (tempStats.max - tempStats.min > 3) {
    insights.push({
      category: "Temperature Regulation",
      finding: "Significant Temperature Variation",
      clinical_significance:
        "Large temperature fluctuations may indicate inflammatory response, infection, or vascular insufficiency.",
      recommendation:
        "Monitor for signs of infection (redness, warmth, swelling). Consider vascular assessment if persistent.",
    })
  } else if (tempStats.mean > 32) {
    insights.push({
      category: "Temperature Regulation",
      finding: "Elevated Baseline Temperature",
      clinical_significance: "Consistently elevated foot temperature may indicate inflammation or early infection.",
      recommendation: "Perform visual inspection for signs of infection. Consider antibiotic prophylaxis if indicated.",
    })
  } else {
    insights.push({
      category: "Temperature Regulation",
      finding: "Normal Temperature Profile",
      clinical_significance:
        "Temperature readings suggest normal vascular perfusion and absence of acute inflammation.",
      recommendation: "Continue routine monitoring and preventive care.",
    })
  }

  // Symmetry Analysis (bilateral only)
  if (isBilateral) {
    const leftPressures: number[] = []
    const rightPressures: number[] = []

    data.forEach((row) => {
      if (row.force_sensor_1_left !== undefined)
        leftPressures.push(row.force_sensor_1_left * CLINICAL_THRESHOLDS.FORCE_TO_KPA_FACTOR)
      if (row.force_sensor_2_left !== undefined)
        leftPressures.push(row.force_sensor_2_left * CLINICAL_THRESHOLDS.FORCE_TO_KPA_FACTOR)
      if (row.force_sensor_1_right !== undefined)
        rightPressures.push(row.force_sensor_1_right * CLINICAL_THRESHOLDS.FORCE_TO_KPA_FACTOR)
      if (row.force_sensor_2_right !== undefined)
        rightPressures.push(row.force_sensor_2_right * CLINICAL_THRESHOLDS.FORCE_TO_KPA_FACTOR)
    })

    const leftStats = calculateStats(leftPressures)
    const rightStats = calculateStats(rightPressures)
    const asymmetry = Math.abs(leftStats.mean - rightStats.mean) / Math.max(leftStats.mean, rightStats.mean)

    if (asymmetry > 0.3) {
      insights.push({
        category: "Gait Symmetry",
        finding: "Significant Pressure Asymmetry",
        clinical_significance:
          "Greater than 30% pressure difference between feet indicates abnormal gait mechanics, possibly due to pain avoidance, weakness, or structural deformity.",
        recommendation:
          "Refer for gait analysis and physical therapy. Assess for underlying musculoskeletal or neurological issues.",
      })
    } else if (asymmetry > 0.15) {
      insights.push({
        category: "Gait Symmetry",
        finding: "Mild Pressure Asymmetry",
        clinical_significance: "Moderate pressure differences suggest some gait abnormality that warrants attention.",
        recommendation: "Monitor for progression. Consider physical therapy evaluation.",
      })
    } else {
      insights.push({
        category: "Gait Symmetry",
        finding: "Symmetric Pressure Distribution",
        clinical_significance: "Balanced pressure distribution indicates normal gait mechanics.",
        recommendation: "Maintain current activity level and footwear.",
      })
    }
  }

  // Risk Stratification
  const highRiskAlerts = alerts.filter((a) => a.severity === "high" || a.severity === "critical").length
  if (highRiskAlerts >= 2) {
    insights.push({
      category: "Risk Stratification",
      finding: "Multiple High-Risk Factors",
      clinical_significance:
        "Combination of multiple risk factors significantly increases ulcer development probability.",
      recommendation:
        "Multidisciplinary approach recommended. Coordinate with podiatry, endocrinology, and vascular medicine.",
    })
  }

  return insights
}

function establishBaseline(
  data: SensorData[],
  isBilateral: boolean,
): {
  temperature_mean: number
  temperature_std: number
  pressure_mean: number
  humidity_mean: number
  baseline_samples: number
} | null {
  if (isBilateral) return null

  // Use first 24 hours (1440 samples at 1 sample/min) as baseline
  const baseline_hours = 24
  const baseline_samples = Math.min(1440, Math.floor(data.length / 2))

  const baseline_data = data.slice(0, baseline_samples)
  const baseline_temps: number[] = []
  const baseline_pressures: number[] = []
  const baseline_humidities: number[] = []

  baseline_data.forEach((row) => {
    if (row.temperature !== undefined) baseline_temps.push(row.temperature)
    if (row.force_sensor_1 !== undefined)
      baseline_pressures.push(row.force_sensor_1 * CLINICAL_THRESHOLDS.FORCE_TO_KPA_FACTOR)
    if (row.force_sensor_2 !== undefined)
      baseline_pressures.push(row.force_sensor_2 * CLINICAL_THRESHOLDS.FORCE_TO_KPA_FACTOR)
    if (row.humidity !== undefined) baseline_humidities.push(row.humidity)
  })

  const temp_stats = calculateStats(baseline_temps)
  const pressure_stats = calculateStats(baseline_pressures)
  const humidity_stats = calculateStats(baseline_humidities)

  return {
    temperature_mean: temp_stats.mean,
    temperature_std: temp_stats.std,
    pressure_mean: pressure_stats.mean,
    humidity_mean: humidity_stats.mean,
    baseline_samples,
  }
}

function analyzeSingleFootWithBaseline(
  data: SensorData[],
  baseline: ReturnType<typeof establishBaseline>,
): {
  alerts: Alert[]
  analysis: { [key: string]: number | string }
  metrics: AnalysisMetrics
} {
  const alerts: Alert[] = []
  const analysis: { [key: string]: number | string } = {}
  const metrics: AnalysisMetrics = {}

  if (!baseline) {
    return { alerts, analysis, metrics }
  }

  const forceSensor1: number[] = []
  const forceSensor2: number[] = []
  const temperature: number[] = []
  const humidity: number[] = []

  data.forEach((row) => {
    if (row.force_sensor_1 !== undefined) forceSensor1.push(row.force_sensor_1)
    if (row.force_sensor_2 !== undefined) forceSensor2.push(row.force_sensor_2)
    if (row.temperature !== undefined) temperature.push(row.temperature)
    if (row.humidity !== undefined) humidity.push(row.humidity)
  })

  const forceStats = calculateStats([...forceSensor1, ...forceSensor2])
  const tempStats = calculateStats(temperature)
  const humidityStats = calculateStats(humidity)

  const forceMeanKpa = forceStats.mean * CLINICAL_THRESHOLDS.FORCE_TO_KPA_FACTOR
  const forceMaxKpa = forceStats.max * CLINICAL_THRESHOLDS.FORCE_TO_KPA_FACTOR

  // Calculate temperature elevation from baseline
  const temp_elevation = tempStats.mean - baseline.temperature_mean
  const max_temp_elevation = tempStats.max - baseline.temperature_mean

  // Metrics
  metrics["Avg Pressure (kPa)"] = forceMeanKpa.toFixed(2)
  metrics["Avg Temperature (°C)"] = tempStats.mean.toFixed(2)
  metrics["Baseline Temperature (°C)"] = baseline.temperature_mean.toFixed(2)
  metrics["Temperature Elevation (°C)"] = temp_elevation.toFixed(2)
  metrics["Avg Humidity (%)"] = humidityStats.mean.toFixed(2)

  // Analysis details
  analysis["Max Pressure (kPa)"] = forceMaxKpa.toFixed(2)
  analysis["Temp Range (°C)"] = (tempStats.max - tempStats.min).toFixed(2)
  analysis["Max Temp Elevation (°C)"] = max_temp_elevation.toFixed(2)
  analysis["Data Points"] = data.length
  analysis["Baseline Period (hours)"] = "24"

  // Temperature elevation alerts (primary risk indicator)
  if (max_temp_elevation > CLINICAL_THRESHOLDS.TEMP_ASYMMETRY_THRESHOLD) {
    alerts.push({
      title: "Critical Temperature Elevation",
      description: `Temperature elevation of ${max_temp_elevation.toFixed(2)}°C above baseline exceeds critical threshold (${CLINICAL_THRESHOLDS.TEMP_ASYMMETRY_THRESHOLD}°C). This is the strongest predictor of ulcer risk.`,
      severity: "critical",
    })
  } else if (max_temp_elevation > CLINICAL_THRESHOLDS.TEMP_MODERATE_THRESHOLD) {
    alerts.push({
      title: "Moderate Temperature Elevation",
      description: `Temperature elevation of ${max_temp_elevation.toFixed(2)}°C above baseline indicates moderate risk. Monitor closely for progression.`,
      severity: "high",
    })
  } else if (temp_elevation > 0.5) {
    alerts.push({
      title: "Slight Temperature Elevation",
      description: `Average temperature is ${temp_elevation.toFixed(2)}°C above baseline. Continue monitoring.`,
      severity: "moderate",
    })
  }

  // Peak pressure detection
  if (forceMaxKpa > CLINICAL_THRESHOLDS.PRESSURE_THRESHOLD_KPA) {
    alerts.push({
      title: "Critical Peak Pressure",
      description: `Peak pressure of ${forceMaxKpa.toFixed(2)} kPa exceeds critical threshold. Risk of ulcer formation.`,
      severity: "critical",
    })
  } else if (forceMaxKpa > 150) {
    alerts.push({
      title: "Very High Pressure",
      description: `Peak pressure of ${forceMaxKpa.toFixed(2)} kPa is very high. High risk of ulcer formation.`,
      severity: "high",
    })
  } else if (forceMaxKpa > 100) {
    alerts.push({
      title: "Elevated Pressure",
      description: `Peak pressure of ${forceMaxKpa.toFixed(2)} kPa is elevated. Monitor closely.`,
      severity: "moderate",
    })
  }

  // Humidity alerts
  if (humidityStats.mean > CLINICAL_THRESHOLDS.HUMIDITY_HIGH_THRESHOLD) {
    alerts.push({
      title: "High Humidity",
      description: `Average humidity of ${humidityStats.mean.toFixed(1)}% exceeds threshold. Check for excessive moisture.`,
      severity: "moderate",
    })
  } else if (humidityStats.mean < CLINICAL_THRESHOLDS.HUMIDITY_LOW_THRESHOLD) {
    alerts.push({
      title: "Low Humidity",
      description: `Average humidity of ${humidityStats.mean.toFixed(1)}% is below threshold. Monitor for skin dryness.`,
      severity: "low",
    })
  }

  return { alerts, analysis, metrics }
}

function analyzeData(data: SensorData[]): AnalysisResult {
  const alerts: Alert[] = []
  const metrics: AnalysisMetrics = {}
  const analysis: { [key: string]: number | string } = {}

  // Determine if bilateral or single foot
  const isBilateral = data.some((d) => d.force_sensor_1_left !== undefined)

  if (!isBilateral) {
    const baseline = establishBaseline(data, isBilateral)
    const singleFootAnalysis = analyzeSingleFootWithBaseline(data, baseline)
    alerts.push(...singleFootAnalysis.alerts)
    Object.assign(metrics, singleFootAnalysis.metrics)
    Object.assign(analysis, singleFootAnalysis.analysis)
  } else {
    // Extract sensor values
    const forceSensor1Left: number[] = []
    const forceSensor2Left: number[] = []
    const temperatureLeft: number[] = []
    const humidityLeft: number[] = []
    const forceSensor1Right: number[] = []
    const forceSensor2Right: number[] = []
    const temperatureRight: number[] = []
    const humidityRight: number[] = []

    data.forEach((row) => {
      if (row.force_sensor_1_left !== undefined) forceSensor1Left.push(row.force_sensor_1_left)
      if (row.force_sensor_2_left !== undefined) forceSensor2Left.push(row.force_sensor_2_left)
      if (row.temperature_left !== undefined) temperatureLeft.push(row.temperature_left)
      if (row.humidity_left !== undefined) humidityLeft.push(row.humidity_left)
      if (row.force_sensor_1_right !== undefined) forceSensor1Right.push(row.force_sensor_1_right)
      if (row.force_sensor_2_right !== undefined) forceSensor2Right.push(row.force_sensor_2_right)
      if (row.temperature_right !== undefined) temperatureRight.push(row.temperature_right)
      if (row.humidity_right !== undefined) humidityRight.push(row.humidity_right)
    })

    const leftForceStats = calculateStats([...forceSensor1Left, ...forceSensor2Left])
    const rightForceStats = calculateStats([...forceSensor1Right, ...forceSensor2Right])
    const leftTempStats = calculateStats(temperatureLeft)
    const rightTempStats = calculateStats(temperatureRight)

    // Convert to kPa for metrics
    const leftForceMeanKpa = leftForceStats.mean * CLINICAL_THRESHOLDS.FORCE_TO_KPA_FACTOR
    const rightForceMeanKpa = rightForceStats.mean * CLINICAL_THRESHOLDS.FORCE_TO_KPA_FACTOR
    const leftForceMaxKpa = leftForceStats.max * CLINICAL_THRESHOLDS.FORCE_TO_KPA_FACTOR
    const rightForceMaxKpa = rightForceStats.max * CLINICAL_THRESHOLDS.FORCE_TO_KPA_FACTOR

    metrics["Left Foot Avg Pressure (kPa)"] = leftForceMeanKpa.toFixed(2)
    metrics["Right Foot Avg Pressure (kPa)"] = rightForceMeanKpa.toFixed(2)
    metrics["Left Foot Avg Temp (°C)"] = leftTempStats.mean.toFixed(2)
    metrics["Right Foot Avg Temp (°C)"] = rightTempStats.mean.toFixed(2)

    analysis["Left Pressure Max (kPa)"] = leftForceMaxKpa.toFixed(2)
    analysis["Right Pressure Max (kPa)"] = rightForceMaxKpa.toFixed(2)
    analysis["Left Temp Range (°C)"] = (leftTempStats.max - leftTempStats.min).toFixed(2)
    analysis["Right Temp Range (°C)"] = (rightTempStats.max - rightTempStats.min).toFixed(2)

    const tempAsymmetry = Math.abs(leftTempStats.mean - rightTempStats.mean)
    analysis["Temperature Asymmetry (°C)"] = tempAsymmetry.toFixed(2)

    if (tempAsymmetry > CLINICAL_THRESHOLDS.TEMP_ASYMMETRY_THRESHOLD) {
      alerts.push({
        title: "Critical Temperature Asymmetry",
        description: `Temperature difference of ${tempAsymmetry.toFixed(2)}°C between feet exceeds critical threshold (${CLINICAL_THRESHOLDS.TEMP_ASYMMETRY_THRESHOLD}°C). This is the strongest predictor of ulcer risk.`,
        severity: "critical",
      })
    } else if (tempAsymmetry > CLINICAL_THRESHOLDS.TEMP_MODERATE_THRESHOLD) {
      alerts.push({
        title: "Moderate Temperature Asymmetry",
        description: `Temperature difference of ${tempAsymmetry.toFixed(2)}°C between feet indicates moderate risk. Monitor closely for progression.`,
        severity: "high",
      })
    }

    // Pressure asymmetry analysis
    const pressureAsymmetryKpa = Math.abs(leftForceMeanKpa - rightForceMeanKpa)
    if (pressureAsymmetryKpa > 50) {
      alerts.push({
        title: "Significant Pressure Asymmetry",
        description: `Pressure difference of ${pressureAsymmetryKpa.toFixed(2)} kPa between feet indicates abnormal gait mechanics.`,
        severity: "high",
      })
    }

    // Peak pressure detection (using clinical threshold)
    if (leftForceMaxKpa > CLINICAL_THRESHOLDS.PRESSURE_THRESHOLD_KPA) {
      alerts.push({
        title: "Critical Peak Pressure - Left Foot",
        description: `Peak pressure of ${leftForceMaxKpa.toFixed(2)} kPa detected. Risk of ulcer formation.`,
        severity: "critical",
      })
    } else if (leftForceMaxKpa > 150) {
      alerts.push({
        title: "Very High Pressure - Left Foot",
        description: `Peak pressure of ${leftForceMaxKpa.toFixed(2)} kPa detected. High risk of ulcer formation.`,
        severity: "high",
      })
    }

    if (rightForceMaxKpa > CLINICAL_THRESHOLDS.PRESSURE_THRESHOLD_KPA) {
      alerts.push({
        title: "Critical Peak Pressure - Right Foot",
        description: `Peak pressure of ${rightForceMaxKpa.toFixed(2)} kPa detected. Risk of ulcer formation.`,
        severity: "critical",
      })
    } else if (rightForceMaxKpa > 150) {
      alerts.push({
        title: "Very High Pressure - Right Foot",
        description: `Peak pressure of ${rightForceMaxKpa.toFixed(2)} kPa detected. High risk of ulcer formation.`,
        severity: "high",
      })
    }
  }

  // Determine overall risk level
  let riskLevel: "low" | "moderate" | "high" | "critical" = "low"
  let riskMessage = "No significant risk factors detected."
  let recommendation = "Continue regular monitoring."

  const criticalAlerts = alerts.filter((a) => a.severity === "critical").length
  const highAlerts = alerts.filter((a) => a.severity === "high").length
  const moderateAlerts = alerts.filter((a) => a.severity === "moderate").length

  if (criticalAlerts > 0) {
    riskLevel = "critical"
    riskMessage = "Critical risk factors detected. Immediate medical attention recommended."
    recommendation = "Seek immediate medical evaluation."
  } else if (highAlerts > 0) {
    riskLevel = "high"
    riskMessage = "High risk factors detected. Close monitoring and medical consultation recommended."
    recommendation = "Schedule medical consultation within 24-48 hours."
  } else if (moderateAlerts > 0) {
    riskLevel = "moderate"
    riskMessage = "Moderate risk factors detected. Increased monitoring recommended."
    recommendation = "Increase monitoring frequency and follow up with healthcare provider."
  }

  const clinicalInsights = generateClinicalInsights(data, isBilateral, alerts, metrics)

  return {
    overall_risk: {
      level: riskLevel,
      message: riskMessage,
      recommendation,
    },
    metrics,
    alerts,
    analysis,
    chart_data: prepareChartData(data, isBilateral),
    data_type: isBilateral ? "bilateral" : "single",
    clinical_insights: clinicalInsights,
  }
}

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const file = formData.get("file") as File

    if (!file) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 })
    }

    const content = await file.text()
    const data = parseCSV(content)

    if (data.length === 0) {
      return NextResponse.json({ error: "No valid data in CSV" }, { status: 400 })
    }

    const results = analyzeData(data)

    return NextResponse.json(results)
  } catch (error) {
    console.error("Analysis error:", error)
    return NextResponse.json({ error: error instanceof Error ? error.message : "Analysis failed" }, { status: 500 })
  }
}
