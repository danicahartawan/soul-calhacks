"use client"

import { useState, useEffect } from "react"
import { Upload, AlertCircle, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import UploadSection from "@/components/upload-section"
import AnalysisResults from "@/components/analysis-results"
import ProcessingAnimation from "@/components/processing-animation"

export default function Home() {
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [analysisResults, setAnalysisResults] = useState(null)
  const [error, setError] = useState("")
  const [uploadedFile, setUploadedFile] = useState(null)

  const handleFileUpload = (file) => {
    setUploadedFile(file)
    setError("")
    setAnalysisResults(null)
  }

  useEffect(() => {
    if (uploadedFile) {
      handleAnalyze()
    }
  }, [uploadedFile])

  const handleAnalyze = async () => {
    if (!uploadedFile) {
      setError("Please upload a CSV file first")
      return
    }

    setIsAnalyzing(true)
    setError("")

    try {
      const formData = new FormData()
      formData.append("file", uploadedFile)

      const response = await fetch("/api/analyze", {
        method: "POST",
        body: formData,
      })

      if (!response.ok) {
        throw new Error("Analysis failed")
      }

      const data = await response.json()
      setAnalysisResults(data)
    } catch (err) {
      setError(err.message || "Failed to analyze data")
    } finally {
      setIsAnalyzing(false)
    }
  }

  return (
    <main className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="mx-auto max-w-7xl px-6 py-8">
          <h1 className="text-3xl font-bold text-foreground">Diabetic Foot Sensor Analysis</h1>
          <p className="mt-2 text-muted-foreground">
            Upload your sensor data to analyze pressure, temperature, and humidity patterns
          </p>
        </div>
      </header>

      {/* Main Content */}
      <div className="mx-auto max-w-7xl px-6 py-12">
        <div className="grid gap-8 lg:grid-cols-3">
          {/* Upload Section */}
          <div className="lg:col-span-1">
            <UploadSection onFileUpload={handleFileUpload} uploadedFile={uploadedFile} />

            {analysisResults && (
              <Button
                onClick={handleAnalyze}
                disabled={isAnalyzing}
                className="mt-6 w-full bg-transparent"
                size="lg"
                variant="outline"
              >
                {isAnalyzing ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Re-analyzing...
                  </>
                ) : (
                  "Re-analyze Data"
                )}
              </Button>
            )}

            {/* Error Message */}
            {error && (
              <Card className="mt-6 border-destructive bg-destructive/10 p-4">
                <div className="flex gap-3">
                  <AlertCircle className="h-5 w-5 text-destructive flex-shrink-0 mt-0.5" />
                  <p className="text-sm text-destructive">{error}</p>
                </div>
              </Card>
            )}

            {/* Info Card */}
            <Card className="mt-6 p-4 bg-card border-border">
              <h3 className="font-semibold text-foreground mb-3">Expected CSV Format</h3>
              <div className="space-y-2 text-sm text-muted-foreground">
                <p>
                  <strong>Bilateral (Recommended):</strong>
                </p>
                <code className="block bg-muted p-2 rounded text-xs overflow-x-auto">
                  timestamp,force_sensor_1_left,force_sensor_2_left,temperature_left,humidity_left,force_sensor_1_right,force_sensor_2_right,temperature_right,humidity_right
                </code>
                <p className="mt-3">
                  <strong>Single Foot:</strong>
                </p>
                <code className="block bg-muted p-2 rounded text-xs overflow-x-auto">
                  timestamp,force_sensor_1,force_sensor_2,temperature,humidity
                </code>
              </div>
            </Card>
          </div>

          {/* Results Section */}
          <div className="lg:col-span-2">
            {isAnalyzing ? (
              <ProcessingAnimation />
            ) : analysisResults ? (
              <AnalysisResults results={analysisResults} />
            ) : (
              <Card className="p-12 text-center border-dashed">
                <Upload className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold text-foreground mb-2">No Analysis Yet</h3>
                <p className="text-muted-foreground">Upload a CSV file to start analyzing sensor data</p>
              </Card>
            )}
          </div>
        </div>
      </div>
    </main>
  )
}
