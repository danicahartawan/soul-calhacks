"use client"

import { AlertCircle, AlertTriangle, CheckCircle2, Info } from "lucide-react"
import { Card } from "@/components/ui/card"
import SensorChart from "@/components/sensor-chart"
import ClinicalInsights from "@/components/clinical-insights"

export default function AnalysisResults({ results }) {
  const getRiskColor = (level) => {
    switch (level) {
      case "critical":
        return "bg-destructive/10 text-destructive border-destructive/20"
      case "high":
        return "bg-orange-500/10 text-orange-700 border-orange-500/20"
      case "moderate":
        return "bg-yellow-500/10 text-yellow-700 border-yellow-500/20"
      default:
        return "bg-green-500/10 text-green-700 border-green-500/20"
    }
  }

  const getRiskIcon = (level) => {
    switch (level) {
      case "critical":
        return <AlertCircle className="h-5 w-5" />
      case "high":
        return <AlertTriangle className="h-5 w-5" />
      case "moderate":
        return <Info className="h-5 w-5" />
      default:
        return <CheckCircle2 className="h-5 w-5" />
    }
  }

  const getPressureChartLines = () => {
    if (results.data_type === "bilateral") {
      return [
        { key: "Pressure L1 (kPa)", color: "#0ea5e9" },
        { key: "Pressure L2 (kPa)", color: "#06b6d4" },
        { key: "Pressure R1 (kPa)", color: "#f97316" },
        { key: "Pressure R2 (kPa)", color: "#ef4444" },
      ]
    }
    return [
      { key: "Pressure 1 (kPa)", color: "#0ea5e9" },
      { key: "Pressure 2 (kPa)", color: "#06b6d4" },
    ]
  }

  const getTemperatureChartLines = () => {
    if (results.data_type === "bilateral") {
      return [
        { key: "Temp Left (°C)", color: "#0ea5e9" },
        { key: "Temp Right (°C)", color: "#ef4444" },
      ]
    }
    return [{ key: "Temperature (°C)", color: "#0ea5e9" }]
  }

  return (
    <div className="space-y-6">
      {/* Overall Risk Assessment */}
      {results.overall_risk && (
        <Card className={`p-6 border ${getRiskColor(results.overall_risk.level)}`}>
          <div className="flex items-start gap-4">
            <div className="mt-1">{getRiskIcon(results.overall_risk.level)}</div>
            <div className="flex-1">
              <h3 className="font-semibold mb-1">Overall Risk Assessment</h3>
              <p className="text-sm mb-2">{results.overall_risk.message}</p>
              {results.overall_risk.recommendation && (
                <p className="text-sm font-medium">Action: {results.overall_risk.recommendation}</p>
              )}
            </div>
          </div>
        </Card>
      )}

      {/* Key Metrics */}
      {results.metrics && (
        <div className="grid gap-4 md:grid-cols-2">
          {Object.entries(results.metrics).map(([key, value]) => (
            <Card key={key} className="p-4">
              <p className="text-sm text-muted-foreground mb-1">{key.replace(/_/g, " ").toUpperCase()}</p>
              <p className="text-2xl font-bold text-foreground">
                {typeof value === "number" ? value.toFixed(2) : value}
              </p>
            </Card>
          ))}
        </div>
      )}

      {/* Clinical Insights */}
      {results.clinical_insights && results.clinical_insights.length > 0 && (
        <ClinicalInsights insights={results.clinical_insights} />
      )}

      {/* Pressure Chart */}
      {results.chart_data && results.chart_data.length > 0 && (
        <SensorChart data={results.chart_data} title="Pressure Sensor Data Over Time" lines={getPressureChartLines()} />
      )}

      {/* Temperature Chart */}
      {results.chart_data && results.chart_data.length > 0 && (
        <SensorChart data={results.chart_data} title="Temperature Data Over Time" lines={getTemperatureChartLines()} />
      )}

      {/* Alerts */}
      {results.alerts && results.alerts.length > 0 && (
        <Card className="p-6">
          <h3 className="font-semibold mb-4">Detected Alerts</h3>
          <div className="space-y-3">
            {results.alerts.map((alert, idx) => (
              <div key={idx} className={`p-3 rounded-lg border flex items-start gap-3 ${getRiskColor(alert.severity)}`}>
                <div className="mt-0.5">{getRiskIcon(alert.severity)}</div>
                <div className="flex-1">
                  <p className="font-medium text-sm">{alert.title}</p>
                  <p className="text-sm mt-1">{alert.description}</p>
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}

      {/* Analysis Details */}
      {results.analysis && (
        <Card className="p-6">
          <h3 className="font-semibold mb-4">Analysis Details</h3>
          <div className="space-y-3 text-sm">
            {Object.entries(results.analysis).map(([key, value]) => (
              <div key={key} className="flex justify-between items-start">
                <span className="text-muted-foreground">{key.replace(/_/g, " ")}:</span>
                <span className="font-medium text-foreground text-right">
                  {typeof value === "number" ? value.toFixed(2) : String(value)}
                </span>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  )
}
