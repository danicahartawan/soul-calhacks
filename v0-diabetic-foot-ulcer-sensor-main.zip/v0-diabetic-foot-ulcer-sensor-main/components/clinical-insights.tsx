"use client"

import { AlertCircle, Lightbulb, Stethoscope } from "lucide-react"
import { Card } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface ClinicalInsight {
  category: string
  finding: string
  clinical_significance: string
  recommendation: string
}

interface ClinicalInsightsProps {
  insights: ClinicalInsight[]
}

export default function ClinicalInsights({ insights }: ClinicalInsightsProps) {
  const categories = Array.from(new Set(insights.map((i) => i.category)))

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "Pressure Distribution":
        return <AlertCircle className="h-5 w-5" />
      case "Temperature Regulation":
        return <Stethoscope className="h-5 w-5" />
      case "Gait Symmetry":
        return <AlertCircle className="h-5 w-5" />
      case "Risk Stratification":
        return <Lightbulb className="h-5 w-5" />
      default:
        return <Lightbulb className="h-5 w-5" />
    }
  }

  return (
    <Card className="p-6">
      <div className="flex items-center gap-2 mb-6">
        <Stethoscope className="h-6 w-6 text-primary" />
        <h2 className="text-xl font-semibold text-foreground">Clinical Insights</h2>
      </div>

      {categories.length > 1 ? (
        <Tabs defaultValue={categories[0]} className="w-full">
          <TabsList
            className="grid w-full gap-2"
            style={{ gridTemplateColumns: `repeat(auto-fit, minmax(150px, 1fr))` }}
          >
            {categories.map((category) => (
              <TabsTrigger key={category} value={category} className="text-xs sm:text-sm">
                {category}
              </TabsTrigger>
            ))}
          </TabsList>

          {categories.map((category) => (
            <TabsContent key={category} value={category} className="space-y-4 mt-4">
              {insights
                .filter((i) => i.category === category)
                .map((insight, idx) => (
                  <div key={idx} className="border border-border rounded-lg p-4 space-y-3">
                    <div className="flex items-start gap-3">
                      <div className="mt-1 text-primary">{getCategoryIcon(insight.category)}</div>
                      <div className="flex-1">
                        <h3 className="font-semibold text-foreground">{insight.finding}</h3>
                      </div>
                    </div>

                    <div className="space-y-2 text-sm">
                      <div>
                        <p className="text-muted-foreground font-medium mb-1">Clinical Significance:</p>
                        <p className="text-foreground">{insight.clinical_significance}</p>
                      </div>

                      <div>
                        <p className="text-muted-foreground font-medium mb-1">Recommendation:</p>
                        <p className="text-foreground">{insight.recommendation}</p>
                      </div>
                    </div>
                  </div>
                ))}
            </TabsContent>
          ))}
        </Tabs>
      ) : (
        <div className="space-y-4">
          {insights.map((insight, idx) => (
            <div key={idx} className="border border-border rounded-lg p-4 space-y-3">
              <div className="flex items-start gap-3">
                <div className="mt-1 text-primary">{getCategoryIcon(insight.category)}</div>
                <div className="flex-1">
                  <h3 className="font-semibold text-foreground">{insight.finding}</h3>
                </div>
              </div>

              <div className="space-y-2 text-sm">
                <div>
                  <p className="text-muted-foreground font-medium mb-1">Clinical Significance:</p>
                  <p className="text-foreground">{insight.clinical_significance}</p>
                </div>

                <div>
                  <p className="text-muted-foreground font-medium mb-1">Recommendation:</p>
                  <p className="text-foreground">{insight.recommendation}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </Card>
  )
}
