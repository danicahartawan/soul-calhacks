"use client"

import { useEffect, useState } from "react"
import { Card } from "@/components/ui/card"
import { CheckCircle2, Loader2 } from "lucide-react"

const PROCESSING_STEPS = [
  { id: 1, label: "Parsing CSV Data", description: "Reading and validating sensor data..." },
  { id: 2, label: "Calculating Statistics", description: "Computing pressure, temperature, and humidity metrics..." },
  { id: 3, label: "Detecting Anomalies", description: "Analyzing patterns and identifying outliers..." },
  { id: 4, label: "Clinical Assessment", description: "Evaluating risk levels and generating insights..." },
  { id: 5, label: "Generating Visualizations", description: "Creating charts and data representations..." },
]

export default function ProcessingAnimation() {
  const [currentStep, setCurrentStep] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentStep((prev) => {
        if (prev < PROCESSING_STEPS.length - 1) {
          return prev + 1
        }
        return prev
      })
    }, 800)

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="space-y-4">
      <Card className="p-6 bg-gradient-to-r from-primary/5 to-primary/10 border-primary/20">
        <div className="flex items-center gap-3 mb-2">
          <Loader2 className="h-5 w-5 text-primary animate-spin" />
          <h3 className="font-semibold text-foreground">Analyzing Your Data</h3>
        </div>
        <p className="text-sm text-muted-foreground">Processing sensor data and generating clinical insights...</p>
      </Card>

      <div className="space-y-3">
        {PROCESSING_STEPS.map((step, index) => (
          <Card
            key={step.id}
            className={`p-4 transition-all duration-300 ${
              index <= currentStep ? "bg-primary/5 border-primary/30" : "bg-muted/30 border-border opacity-50"
            }`}
          >
            <div className="flex items-start gap-3">
              <div className="mt-1">
                {index < currentStep ? (
                  <CheckCircle2 className="h-5 w-5 text-green-500 animate-pulse" />
                ) : index === currentStep ? (
                  <Loader2 className="h-5 w-5 text-primary animate-spin" />
                ) : (
                  <div className="h-5 w-5 rounded-full border-2 border-muted-foreground/30" />
                )}
              </div>
              <div className="flex-1">
                <p className={`font-medium ${index <= currentStep ? "text-foreground" : "text-muted-foreground"}`}>
                  {step.label}
                </p>
                <p
                  className={`text-sm mt-1 ${index <= currentStep ? "text-muted-foreground" : "text-muted-foreground/60"}`}
                >
                  {step.description}
                </p>
              </div>
            </div>
          </Card>
        ))}
      </div>

      <Card className="p-4 bg-muted/30 border-border">
        <p className="text-xs text-muted-foreground text-center">
          Step {currentStep + 1} of {PROCESSING_STEPS.length}
        </p>
      </Card>
    </div>
  )
}
